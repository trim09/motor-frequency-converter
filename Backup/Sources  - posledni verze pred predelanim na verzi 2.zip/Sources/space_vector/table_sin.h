#include <stdint.h>

#define TAB_SIN_SCALE 256
#define TAB_SIN_SIZE  (sizeof(tab_sin) / sizeof(tab_sin[0]))

const uint8_t tab_sin[125];

