#ifndef CONTROLVF_H_
#define CONTROLVF_H_

#include <stdint.h>

uint16_t controlVF(uint16_t angle_increment_scaled);

#endif /* CONTROLVF_H_ */
