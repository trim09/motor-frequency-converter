#ifndef SPEED_CONTROL_H_
#define SPEED_CONTROL_H_

#include <stdint.h>

int16_t get_command(int16_t real_speed, int16_t requested_speed);

#endif /* SPEED_CONTROL_H_ */
