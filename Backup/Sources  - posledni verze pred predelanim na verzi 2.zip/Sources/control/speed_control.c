#include "speed_control.h"

int16_t get_command(int16_t real_speed, int16_t requested_speed) {
	//compute the stator frequency (PI controller)
	//command = mc_control_speed_16b(Omega_ref,Omega_meas); // for use in closed loop
	//command = ((512 - Omega_meas) * 20) / 10; // command with the on board pot
	//command = request ; // command with the generated steps
#if SPEED_CONTROL_TYPE == NONE
	return requested_speed;
#else
#	error This type of speed control is unsupported.
#endif
}
