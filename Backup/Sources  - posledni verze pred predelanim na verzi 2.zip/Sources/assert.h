#ifndef ASSERT_H_
#define ASSERT_H_

#define DEBUG

#ifdef DEBUG
#include <stdlib.h>
//#define assert(e) ((e) ? (void)0 : assert_handle(__func__, __FILE__, __LINE__, #e))
#define assert(e) ((e) ? ((void)0) : assert_handle(__LINE__))
void assert_handle(int line) __ATTR_NORETURN__;

#else
#define assert(e) ((void)0)
#endif

#define MAX_VALUE(var) ((1ULL << (8 * sizeof(var))) - 1ULL)

/* compile time assert */
#define cassert(pred) switch(0) {case 0: case (pred): ;}

#endif /* ASSERT_H_ */
