#include "uart.h"

void uart_init(void) {
    /* Set baud rate */
    UBRRH = UBRRH_VALUE;
    UBRRL = UBRRL_VALUE;
    /* Clear TXC and set/clear double speed mode */
    UCSRA = (1<<TXC) | (USE_2X<<U2X);
    /* Set frame format: 8data, no parity & 1 stop bit */
    UCSRC = (1<<UCSZ1) | (1<<UCSZ0);
    /* Enable receiver and transmitter */
    UCSRB = (1<<RXEN) | (1<<TXEN);
}

char uart_getchar(void) {
    /* Wait for data to be received */
    while (true == uart_isRXempty())
        ;
    /* Get and return received data from buffer */
    return UDR;
}

void uart_putchar(char c) {
    /* Wait for empty transmit buffer */
    while (false == uart_isTXempty())
        ;
    /* Put data into buffer, sends the data */
    UDR = c;
}

void uart_puthex(char d) {
	static const char dtox_lookup[16] = {
			'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
			'A', 'B', 'C', 'D', 'E', 'F'};
	uart_putchar(dtox_lookup[d >> 4]);
	uart_putchar(dtox_lookup[d & 0x0f]);
}

void uart_putd(uint16_t d) {
	uart_putchar('0');
	uart_putchar('x');
	uart_puthex((char)(d >> 8));
	uart_puthex(((char)d & 0x00FF));
}

void uart_puts(const char * string) {
    uint8_t tmp;
    tmp = *(string++);
    while (tmp != '\0') {
        uart_putchar(tmp);
        tmp = *(string++);
    }
}

void uart_putnewline(void) {
	uart_putchar('\r');
	uart_putchar('\n');
}

void uart_puts_P(const prog_char * string) {
    uint8_t tmp;
    tmp = pgm_read_byte(string++);
    while (tmp != '\0') {
        uart_putchar(tmp);
        tmp = pgm_read_byte(string++);
    }
}

void uart_putsn_P(const prog_char * string) {
	uart_puts_P(string);
	uart_putnewline();
}

void uart_vt100_clear_screen(void) {
	uart_putchar(27);
	uart_putchar('[');
	uart_putchar('2');
	uart_putchar('J');
}

