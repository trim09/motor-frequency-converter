#ifndef LED_H_
#define LED_H_

void led_init(void);
void led_toggle(void);

#endif /* LED_H_ */
