
#include <avr/io.h>
#include <avr/interrupt.h>
#include "adc.h"
#include "assert.h"
#include <util/atomic.h>
#include "multiplication/mult16x8.h"
#include "divide/div16.h"

#define ADC_FILTER_LEN 64

static int16_t adc_value;

void adc_Init(void) {
	/* enable VCC ref, right adjust the ADC result, cannel ADC06 */
	ADMUX = (1<<REFS0) | (0<<MUX3 | 1<<MUX2 | 1<<MUX1 | 0<<MUX0);

    /* enable ADC, enable interrupts,  ADC Prescaler = 128, Auto trigger mode */
    ADCSRA = (1 << ADEN) | (1<<ADIE) | (1<<ADPS2) | (1<<ADPS1) | (1<<ADPS0) | (1<<ADATE);
    /* Free Running Mode */
    ADCSRB = 0;

    /* start conversion */
    ADCSRA |= 1<<ADSC;
}

int16_t adc_get_value(void) {
	int16_t retval;

	ATOMIC_BLOCK(ATOMIC_RESTORESTATE) {
		retval = adc_value;
	}

	/* slow */
	retval /= ADC_FILTER_LEN;
	/* fast */
	//	cassert(ADC_FILTER_LEN == 64);
	//	DivS16_64(retval, retval);

	return retval;
}


/* adc_value = (adc_value * (ADC_FILTER_LEN - 1) / ADC_FILTER_LEN) + ADC; */
ISR(ADC_vect) {
	int16_t new_val = ADC;

	/* adc_value * (ADC_FILTER_LEN - 1) / ADC_FILTER_LEN =>
	 * adc_value - adc_value * 1 / ADC_FILTER_LEN */
	/* slow (use DivS16_64() to speed it up) */
	adc_value -= adc_value / ADC_FILTER_LEN;

	/* convert from shifted code to 2's complement code */
	// when the ADC output is higher than 512, the measure is positive
	// when the ADC output is lower  then 512, the measure is negative
	asm ("bst	%B[new_val], 1;	\n\t"
		 "cbr	%B[new_val], 0x02; \n\t"
		 "brts	end; \n\t"
		 "ori	%B[new_val], 0xFE; \n\t"
		 "end:"
		 :[new_val] "+a" (new_val));

	adc_value += new_val;
}



