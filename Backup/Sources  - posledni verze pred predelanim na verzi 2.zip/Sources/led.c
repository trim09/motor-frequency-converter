#include <avr/io.h>

/* Port, na ktery je pripojena led */
#define LED_PORT PORTC
/* DDR registr, na ktery je pripojena led */
#define LED_DDR  DDRC
/* Pin, na ktery je pripojena led */
#define LED      PC1

/* Nastavi DDR registr, aby bylo mozne ovladat ledku - pin ledky jako vystupni */
void led_init() {
    LED_DDR |= 1 << LED;
}

/* Zmeni stav ledky*/
void led_toggle(){
    LED_PORT ^=  1 << LED; // XOR
}
