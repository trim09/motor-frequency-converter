#ifndef TEST_MULT16X8_H_
#define TEST_MULT16X8_H_

void test_mult16x8(void);

#endif /* TEST_MULT16X8_H_ */
