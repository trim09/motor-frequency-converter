#include <avr/io.h>
#include <stdbool.h>
#include <avr/interrupt.h>
#include <util/delay.h>

#include "assert.h"
#include "config.h"
#include "common.h"
#include "led.h"
#include "adc.h"
#include "dac.h"
#include "uart.h"
#include "control/controlVF.h"
#include "control/speed_control.h"
#include "space_vector/psc.h"
#include "space_vector/vector_recalculation.h"
#include "multiplication/mult16x8.h"
#include "multiplication/test_mult16x8.h"

static int16_t dummy_get_real_speed(void) {
	return 0;
}

/* returns value from -512 to 511
 *
 *    0 = stop
 *    1 = forward  F_MAX/COMMAND_MAX hz
 *   -1 = backward F_MAX/COMMAND_MAX hz
 *  511 = forward  F_MAX hz
 * -512 = backward F_MAX + F_MAX/COMMAND_MAX hz
 * */
static inline int16_t dummy_get_requested_speed(void) {
	return adc_get_value();
}

/* Timer 0 Configuration */
static void timer0_init (void) {
	cassert(TIMER0_DIVIDER == 64);
	TCCR0B = (1 << CS01) | (1 << CS00);  // f_quartz = 16 MHz / 64 = 250 kHz
	TCCR0A = (1 << WGM01); // mode CTC : Clear Timer on Compare
	OCR0A  = OCR0A_VAL;
	TIMSK0 = (1 << OCIE0A); // allow interruption when timer=compare
}

#include <stdio.h> /* TODO for testing */
volatile uint16_t    test_angle_increment_scaled; /* TODO */
volatile uint16_t    test_command_abs; /* TODO */
volatile int16_t     test_amplitude; /* TODO */
//#include <stdio.h> /* TODO */
//extern uint16_t    test_angle_increment_scaled; /* TODO */
//extern uint16_t    test_command_abs; /* TODO */
//extern int16_t     test_amplitude; /* TODO */

int main(void) {
	//test_mult16x8();
	dac_init();
	uart_init();
	led_init();
	adc_Init();
	cassert(MAX_PWM < (1 << 12));
	psc_init(MAX_PWM, DEADTIME);
	timer0_init();

	sei(); // allow interruptions,

	while (1) {
        led_toggle();
		//_delay_ms(500);

        char s[20];/* TODO */
        sprintf(s, "%u", test_angle_increment_scaled);/* TODO */
        uart_puts("angle:");
        uart_puts(s);/* TODO */
        uart_putnewline();/* TODO */

    	sprintf(s, "%u", test_command_abs);/* TODO */
    	uart_puts("absolute:");
    	uart_puts(s);/* TODO */
    	uart_putnewline();/* TODO */

    	sprintf(s, "%u", test_amplitude);/* TODO */
    	uart_puts("amplitude:");
    	uart_puts(s);/* TODO */
    	uart_putnewline();/* TODO */
    	uart_putnewline();/* TODO */
    	uart_putnewline();/* TODO */

	}
}

/* This is called every OCR0A_VAL * TIMER0_DIVIDER / F_CPU second => 0.256ms.
 * One angle unit = 360 / 6 / TAB_SIN_SIZE = 0.48 degree
 *
 * stator speed 100 Hz:
 *    degrees per call = 360 * 100hz * 256us = 9.216
 *    angle units per call = degrees per call / one angle unit = 9.216 / 0.48 = 19.2
 *
 *
 * stator speed 1 Hz:
 *    degrees per call = 360 * 1hz * 256us = 0.09216
 *    angle units per call = degrees per call / one angle unit = 0.09216 / 0.48 = 0.192
 *
 *
 *  19.200 * ANGLE_INTEGRATOR_SCALE = 4915,200
 *   0.192 * ANGLE_INTEGRATOR_SCALE =   49,152
 */
ISR(TIMER0_COMPA_vect) {
	int16_t     command, real_speed, requested_speed;
	uint16_t    angle_increment_scaled;
	uint16_t    command_abs;
	direction_e direction;
	uint16_t    amplitude;

	real_speed = dummy_get_real_speed();
	assert((real_speed >= -SPEED_MAX) && (real_speed <= SPEED_MAX));

	requested_speed = dummy_get_requested_speed();
	assert((requested_speed >= -SPEED_MAX) && (requested_speed <= SPEED_MAX));

	command = get_command(real_speed, requested_speed);
	assert((command >= -COMMAND_MAX) && (command <= COMMAND_MAX));

	/* direction management : extract sign and absolute value */
	if (command > 0) {
		direction = FORWARD;
		command_abs = command;
	} else {
		direction = BACKWARD;
		command_abs = -command;
	}

	/* angle_increment = ANGLE_INTEGRATOR_SCALE * ANGLE_INCREMENT_MAX * (command_abs / COMMAND_MAX); */
	cassert((ANGLE_SCALE * ANGLE_INCREMENT_MAX / COMMAND_MAX)
			<= MAX_VALUE(angle_increment_scaled) / COMMAND_MAX); /* prevent overflow */
	cassert((ANGLE_SCALE * ANGLE_INCREMENT_MAX / COMMAND_MAX) > 0); /* shouldn't be zero */
	cassert(((ANGLE_SCALE * ANGLE_INCREMENT_MAX) % COMMAND_MAX) == 0); /* prevent rounding errors */
	cassert(ANGLE_INCREMENT_MAX_NUMERATOR % ANGLE_INCREMENT_MAX_DENOMINATOR == 0); /* prevent rounding errors */
	/* angle_increment = command_abs * (ANGLE_INTEGRATOR_SCALE * ANGLE_INCREMENT_MAX / COMMAND_MAX); */
	MultiSU16XConst8toL16(angle_increment_scaled, command_abs, ANGLE_SCALE * ANGLE_INCREMENT_MAX / COMMAND_MAX);
	assert(angle_increment_scaled <= ANGLE_INCREMENT_MAX * ANGLE_SCALE); /* TODO can be removed, proved by previous assertions */

	// ------------------------ V/f law --------------------------
	amplitude = controlVF(angle_increment_scaled / ANGLE_SCALE);
	assert(amplitude <= AMPLITUDE_MAX);

	vector_set_new_speed(amplitude, angle_increment_scaled, direction);

//		/* test the overcurrent input */
//		if ((PIFR0 & (1 << PEV0A)) != 0) {
//			/* fault on overcurrent */
//			Set_PC7();
//			Set_PC3();
//			Clear_PE1();
//			while (1)
//				; /* infinite loop */
//		}

	test_angle_increment_scaled = angle_increment_scaled; /* TODO */
	test_command_abs = command_abs; /* TODO */
	//test_direction = direction; /* TODO */
	test_amplitude = amplitude; /* TODO */

	/* Match Flag must be still cleared otherwise we are too slow */
	assert((TIFR0 & (1 << OCF0A)) == 0);
}


