#include <stdint.h>
#include "../assert.h"
#include "mult16x8.h"

#ifdef DEBUG

void test_mult16x8(void) {
	uint16_t u16;
	uint8_t  u8;
	uint16_t s16;
//	int8_t   i8;

	uint16_t ru16;
	uint32_t ru32;
	int16_t  rs16;
//	int32_t  ri32;

	for (u16 = 0; u16 < UINT16_MAX; ++u16) {
		for (u8 = 0; u8 < UINT8_MAX; ++u8) {
			MultiUU16X8toL16(ru16, u16, u8);
			assert((uint16_t)(u16 * (uint16_t)u8) == ru16);
		}
	}

	for (u16 = 0; u16 < UINT16_MAX; ++u16) {
		for (u8 = 0; u8 < UINT8_MAX; ++u8) {
			MultiUU16X8toH16(ru16, u16, u8);
			assert(((uint32_t)u16 * (uint32_t)u8) >> 8 == ru16);
		}
	}

	for (s16 = INT16_MIN; s16 < INT16_MAX; ++s16) {
		for (u8 = 0; u8 < UINT8_MAX; ++u8) {
			MultiSU16X8toH16(rs16, s16, u8);
			assert(((uint32_t)s16 * (uint32_t)u8) / 256 == rs16);
		}
	}

	for (u16 = 0; u16 < UINT16_MAX; ++u16) {
		for (u8 = 0; u8 < UINT8_MAX; ++u8) {
			MultiUU16X8to24(ru32, u16, u8);
			assert(((uint32_t)u16 * (uint32_t)u8) == ru32);
		}
	}

	for (s16 = INT16_MIN; s16 < INT16_MAX; ++s16) {
		for (u8 = 0; u8 < UINT8_MAX; ++u8) {
			MultiSU16X8toL16(ru16, s16, u8);
			assert((((uint32_t)s16 * (uint32_t)u8) & 0xffff) == ru16);
		}
	}


//#define MultiSU16XConst8toL16(intRes, int16In, int8In)
//#define MultiSU16Xconst8toH16(intRes, int16In, int8In)
//#define MultiUU16XConst8toL16(intRes, int16In, int8In)
//#define MultiUU16Xconst8toH16(intRes, int16In, int8In)

//#define MultiSU16X8toH16Round(intRes, int16In, int8In)
}
#endif
