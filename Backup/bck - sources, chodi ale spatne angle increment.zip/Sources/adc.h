#ifndef ADC_H_
#define ADC_H_

void adc_Init(void);
int16_t adc_get_value(void);
void dac_set_value_scaled(uint16_t value, uint16_t max_value);

#endif /* ADC_H_ */
