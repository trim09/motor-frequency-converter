#include "controlVF.h"
#include "../config.h"
#include "../assert.h"
#include "../multiplication/mult16x8.h"

/* This module requires/depends on:
 * ANGLE_INCREMENT_MAX, F_MAX, MAX_PWM
 * */

/* OMEGA_MAX = ANGLE_INCREMENT_MAX * (50hz / F_MAX) */
#define ANGLE_INCREMENT_50hz ((ANGLE_INCREMENT_MAX * (50 + F_MAX / 2)) / F_MAX)
#define ANGLE_INCREMENT_MIN  (ANGLE_INCREMENT_50hz / 10) /* 10% of ANGLE_INCREMENT_MAX */

#define Vf_SLOPE_NUMERATOR   AMPLITUDE_MAX
#define Vf_SLOPE_DENOMINATOR ANGLE_INCREMENT_50hz
#define Vf_SLOPE             (Vf_SLOPE_NUMERATOR / Vf_SLOPE_DENOMINATOR)

#define AMPLITUDE_MIN        (Vf_SLOPE * ANGLE_INCREMENT_MIN)

/* V/f law
 * IN:     "angle_increment" must not be scaled !!!
 * RETURN: PWM max value (will be used in PSC and waveform generation)
 *
 * The return value never exceeds VOLTAGE_MAX, if "angle_increment" doesn't
 * exceeds ANGLE_INCREMENT_MAX.
 */
uint16_t controlVF(uint8_t angle_increment) {
	uint16_t amplitude;

	cassert(Vf_SLOPE >= 0x01); /* shouldn't be zero, otherwise the following algorithm doesn't work */
	cassert(Vf_SLOPE <= 0xFF); /* we will want to cast it to 8bit */
	/* prevent rounding errors - numerator at least 20 times bigger than denominator */
	cassert(Vf_SLOPE_NUMERATOR   >= 20 * Vf_SLOPE_DENOMINATOR);
	cassert(ANGLE_INCREMENT_MAX  <= MAX_VALUE(angle_increment));
	cassert(ANGLE_INCREMENT_50hz <= ANGLE_INCREMENT_MAX); /* just for sure */
	cassert(ANGLE_INCREMENT_MIN  >= 0x01); /* shouldn't be zero, otherwise the following algorithm doesn't work */
	cassert(ANGLE_INCREMENT_50hz * Vf_SLOPE <= AMPLITUDE_MAX); /* should be at most VOLTAGE_MAX */
	cassert(AMPLITUDE_MAX - ANGLE_INCREMENT_50hz * Vf_SLOPE < Vf_SLOPE); /* prevent errors */

	if (angle_increment <= ANGLE_INCREMENT_MIN) { // boost frequency
		amplitude = AMPLITUDE_MIN; // boost voltage
	} else if (angle_increment >= ANGLE_INCREMENT_50hz) {
		amplitude = AMPLITUDE_MAX; // rated value
	} else {
		cassert(Vf_SLOPE <= UINT8_MAX);
		amplitude = angle_increment * (uint8_t)Vf_SLOPE; /* V/f law */
	}

	return amplitude;
}
