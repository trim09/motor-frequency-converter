#ifndef CONTROLVF_H_
#define CONTROLVF_H_

#include <stdint.h>

uint16_t controlVF(uint8_t angle_increment);

#endif /* CONTROLVF_H_ */
