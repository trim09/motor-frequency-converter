
#include "assert.h"
#include "uart.h"
#include "space_vector/psc.h"
#include "led.h"
#include <avr/interrupt.h>
#include <util/delay.h>

#ifdef DEBUG
static const char ASSERTION_FAILED[] PROGMEM = "Assertion failed at line: ";

void assert_handle(int line) {
	cli();
	psc_halt();
	led_init();

	uart_puts_P(ASSERTION_FAILED);
	uart_putd(line);
	uart_putchar('\n');

	while(1) {
		led_toggle();
		_delay_ms(200);
	}
}

#endif
